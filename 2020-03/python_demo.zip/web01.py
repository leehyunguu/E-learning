# web01.py 
import urllib.request
from bs4 import BeautifulSoup

page = urllib.request.urlopen('http://ksp.credu.com/ksp/servlet/controller.gate.course.CourseListServlet?p_process=select-course&p_grcode=000002&p_menucd=M0011&p_field=101&p_leftid=101000000000000&p_searchgubun=A')

#검색이 용이한 soup객체를 생성합니다. 
#Break Point 
soup = BeautifulSoup(page, 'html.parser')

#<td>태그를 검색한다. 
print(soup.find_all("td"))