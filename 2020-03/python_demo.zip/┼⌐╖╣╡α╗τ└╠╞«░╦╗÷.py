from bs4 import BeautifulSoup
import urllib.request
import re 

data ='http://ksp.credu.com/ksp/servlet/controller.gate.course.CourseListServlet?p_process=select-course&p_grcode=000002&p_menucd=M0011&p_field=101003&p_leftid=101003000000000&p_searchgubun=A'
data = urllib.request.urlopen(data).read()
page = data.decode('utf-8', 'ignore')
soup = BeautifulSoup(page, 'html.parser')

list = soup.find_all('td', attrs={'class':'title'})

# 첫번째 강의명을 가져와서 출력해 본다. 
# title = list[0].find('a').get_text()
# print(title)

for item in list:
        try:
                title = item.find('a').get_text()
                print(title.strip())
        except:
                pass 
        
